// Basic Service Worker for PWA installation
const CACHE_NAME = 'lifeflow-cache-v1';

self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(clients.claim());
});

self.addEventListener('fetch', (event) => {
  // Pass through all requests for now, this is just to enable "Add to Home Screen"
  event.respondWith(fetch(event.request));
});
